import config
import torch
import torch.optim as optim
import pandas as pd
import os
from openpyxl import load_workbook, Workbook
from model import YOLOv3
from tqdm import tqdm
from utils import (
    mean_average_precision,
    cells_to_bboxes,
    get_evaluation_bboxes,
    save_checkpoint,
    load_checkpoint,
    check_class_accuracy,
    get_loaders,
    plot_couple_examples
)
from loss import YoloLoss
import warnings
warnings.filterwarnings("ignore")

# Initialisieren der Listen für Tracking
loss_values = []
lr_values = []
num_images = []

# Ordner für Excel-Dateien erstellen
OUTPUT_DIR = "Aufzeichnung"
os.makedirs(OUTPUT_DIR, exist_ok=True)

def append_to_excel(file_path, data_dict):
    """Daten an eine bestehende Excel-Datei anhängen."""
    try:
        book = load_workbook(file_path)
        sheet = book.active
    except FileNotFoundError:
        book = Workbook()
        sheet = book.active
        # Header hinzufügen
        sheet.append(list(data_dict.keys()))

    # Daten hinzufügen
    sheet.append(list(data_dict.values()))
    book.save(file_path)

def train_fn(train_loader, model, optimizer, loss_fn, scaled_anchors, epoch):
    global loss_values, lr_values, num_images
    loop = tqdm(train_loader, leave=True)
    total_images = 0

    # Dateinamen basierend auf der aktuellen Epoche
    loss_file = os.path.join(OUTPUT_DIR, f"loss_values_epoch_{epoch}.xlsx")
    lr_file = os.path.join(OUTPUT_DIR, f"lr_values_epoch_{epoch}.xlsx")

    # Initialisiere neue Excel-Dateien für diese Epoche
    pd.DataFrame(columns=["Anzahl Bilder", "Loss"]).to_excel(loss_file, index=False)
    pd.DataFrame(columns=["Anzahl Bilder", "Learning Rate"]).to_excel(lr_file, index=False)

    for batch_idx, (x, y) in enumerate(loop):
        x = x.to(config.DEVICE)
        y0, y1, y2 = (
            y[0].to(config.DEVICE),
            y[1].to(config.DEVICE),
            y[2].to(config.DEVICE),
        )

        # Entfernen von torch.cuda.amp.autocast(), da es CUDA-spezifisch ist
        out = model(x)
        loss = (
            loss_fn(out[0], y0, scaled_anchors[0])
            + loss_fn(out[1], y1, scaled_anchors[1])
            + loss_fn(out[2], y2, scaled_anchors[2])
        )

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Update der Tracking-Werte
        total_images += x.size(0)  # Anzahl der verarbeiteten Bilder
        current_lr = optimizer.param_groups[0]['lr']  # Aktuelle Learning Rate

        num_images.append(total_images)
        loss_values.append(loss.item())
        lr_values.append(current_lr)

        # Update der Excel-Dateien für die aktuelle Epoche
        append_to_excel(loss_file, {"Anzahl Bilder": total_images, "Loss": loss.item()})
        append_to_excel(lr_file, {"Anzahl Bilder": total_images, "Learning Rate": current_lr})

        # Fortschrittsanzeige aktualisieren
        mean_loss = sum(loss_values[-len(loop):]) / len(loss_values[-len(loop):])
        loop.set_postfix(loss=mean_loss, lr=current_lr)


def main():
    model = YOLOv3(num_classes=config.NUM_CLASSES).to(config.DEVICE)
    optimizer = optim.Adam(
        model.parameters(), lr=config.LEARNING_RATE, weight_decay=config.WEIGHT_DECAY
    )
    loss_fn = YoloLoss()

    train_loader, test_loader, train_eval_loader = get_loaders(
        train_csv_path=config.DATASET + "/train.csv", test_csv_path=config.DATASET + "/test.csv"
    )

    if config.LOAD_MODEL:
        load_checkpoint(
            config.CHECKPOINT_FILE, model, optimizer, config.LEARNING_RATE
        )

    scaled_anchors = (
        torch.tensor(config.ANCHORS)
        * torch.tensor(config.S).unsqueeze(1).unsqueeze(1).repeat(1, 3, 2)
    ).to(config.DEVICE)

    for epoch in range(config.NUM_EPOCHS):
        print(f"Epoch {epoch + 1}/{config.NUM_EPOCHS}")
        train_fn(train_loader, model, optimizer, loss_fn, scaled_anchors, epoch)

        if (epoch + 1) % 4 == 0:  # Nach jeder vierten Epoche speichern
            checkpoint_filename = f"checkpoint_epoch_{epoch + 1}.pth.tar"
            save_checkpoint(model, optimizer, filename=checkpoint_filename)
            print(f"Model checkpoint saved at epoch {epoch + 1}")

        if epoch > 0 and epoch % 3 == 0:
            check_class_accuracy(model, test_loader, threshold=config.CONF_THRESHOLD)
            pred_boxes, true_boxes = get_evaluation_bboxes(
                test_loader,
                model,
                iou_threshold=config.NMS_IOU_THRESH,
                anchors=config.ANCHORS,
                threshold=config.CONF_THRESHOLD,
            )
            mapval = mean_average_precision(
                pred_boxes,
                true_boxes,
                iou_threshold=config.MAP_IOU_THRESH,
                box_format="midpoint",
                num_classes=config.NUM_CLASSES,
            )
            print(f"MAP: {mapval.item()}")
            model.train()


if __name__ == "__main__":
    main()
