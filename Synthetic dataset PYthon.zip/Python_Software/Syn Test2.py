import random
from PIL import Image


def random_rotate(image):
    """Rotate an image by a random angle between 0 and 360 degrees."""
    angle = random.randint(0, 360)  # Ganzzahliger Winkel
    return image.rotate(angle, expand=True)  # Nur das rotierte Bild zurückgeben


def check_overlap(position, size, existing_positions, padding=10):
    """Check if the new position overlaps with any existing positions."""
    for existing_position in existing_positions:
        if (
                position[0] < existing_position[0] + existing_position[2] + padding and
                position[0] + size[0] > existing_position[0] - padding and
                position[1] < existing_position[1] + existing_position[3] + padding and
                position[1] + size[1] > existing_position[1] - padding
        ):
            return True
    return False


def place_bees_on_background(background_path, bee_images, output_image_path, output_label_path, max_bees=8):
    """Place a random number of bees on a background image and create a label file."""
    background = Image.open(background_path).convert("RGBA")

    num_bees = random.randint(1, max_bees)
    existing_positions = []

    # Liste für die Labels
    labels = []

    for _ in range(num_bees):
        bee_image = random.choice(bee_images).copy()  # Kopiere das Bild für jede Biene
        rotated_bee_image = random_rotate(bee_image)  # Rotation anpassen

        # Bestimme zufällige Position für die Biene
        max_x = background.width - rotated_bee_image.width
        max_y = background.height - rotated_bee_image.height
        position = (random.randint(0, max_x), random.randint(0, max_y))

        # Maximale Anzahl an Versuchen, um eine gültige Position zu finden
        max_attempts = 100
        attempts = 0

        # Überprüfe, ob die Position nicht überlappt
        while check_overlap(position, rotated_bee_image.size, existing_positions):
            position = (random.randint(0, max_x), random.randint(0, max_y))
            attempts += 1

            # Wenn die maximale Anzahl an Versuchen erreicht ist, breche ab
            if attempts >= max_attempts:
                print("Maximale Versuche erreicht, Biene wird nicht platziert.")
                break

        # Wenn eine gültige Position gefunden wurde, füge die Biene hinzu
        if attempts < max_attempts:
            # Füge die Biene zum Hintergrund hinzu
            background.paste(rotated_bee_image, position, rotated_bee_image)

            # Speichere die Position für die YOLO-Labels
            labels.append((position[0], position[1], rotated_bee_image.width, rotated_bee_image.height))
            existing_positions.append((position[0], position[1], rotated_bee_image.width, rotated_bee_image.height))

    # Speichere das Ergebnis
    background.save(output_image_path, "PNG")
    print(f"Bild gespeichert unter: {output_image_path}")

    # Erstelle die Label-Datei im YOLO-Format
    with open(output_label_path, "w") as label_file:
        for (x, y, width, height) in labels:
            # Berechnung der relativen Koordinaten
            center_x = (x + width / 2) / background.width
            center_y = (y + height / 2) / background.height
            rel_width = width / background.width
            rel_height = height / background.height

            # YOLO-Format: Klasse, center_x, center_y, width, height
            label_file.write(f"0 {center_x:.6f} {center_y:.6f} {rel_width:.6f} {rel_height:.6f}\n")


# Bilder nur einmal laden
bee_image_paths = ["bee1.png", "bee2.png", "bee3.png", "bee4.png", "bee5.png", "bee6.png", "bee7.png", "bee8.png", "bee9.png", "bee10.png", "bee11.png", "bee12.png", "bee13.png", "bee14.png"]  # Pfade zu Bienenbildern
bee_images = [Image.open(path).convert("RGBA") for path in bee_image_paths]  # Alle Bilder laden

try:
    for i in range(12000):
        background_image_path = "Hintergrund.png"  # Pfad zum Hintergrundbild
        output_image_path = fr"D:\Bienenerkennung Ki\Synthetischen Datensatz\SYN_Datensatz\{i}.png"  # Pfad, um das Ergebnis zu speichern
        output_label_path = fr"D:\Bienenerkennung Ki\Synthetischen Datensatz\SYN_Datensatz\{i}.txt"  # Pfad zur Label-Datei
        place_bees_on_background(background_image_path, bee_images, output_image_path, output_label_path)
finally:
    # Schließe alle Bilder nach dem Erstellen der Bilder
    print("Schließe alle Bildobjekte...")
    for img in bee_images:
        img.close()
